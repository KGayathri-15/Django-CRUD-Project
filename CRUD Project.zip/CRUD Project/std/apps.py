from django.apps import AppConfig


class StdConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'std'
